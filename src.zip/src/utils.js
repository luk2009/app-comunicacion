/**
 * Convierte una cadena base64 a un ArrayBuffer.
 * Esto es necesario para decodificar los datos de audio de la API.
 * @param {string} base64 - La cadena de datos en base64.
 * @returns {ArrayBuffer} - El ArrayBuffer decodificado.
 */
export function base64ToArrayBuffer(base64) {
  const binaryString = window.atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}

/**
 * Convierte datos de audio PCM a un Blob en formato WAV.
 * La API de TTS devuelve audio PCM crudo, y los navegadores necesitan un contenedor
 * como WAV para poder reproducirlo. Esta función construye la cabecera WAV necesaria.
 * @param {Int16Array} pcmData - Los datos de audio PCM de 16 bits.
 * @param {number} numChannels - El número de canales de audio (1 para mono).
 * @param {number} sampleRate - La frecuencia de muestreo (ej. 24000).
 * @returns {Blob} - Un Blob que contiene el audio en formato WAV.
 */
export function pcmToWav(pcmData, numChannels, sampleRate) {
  const bitsPerSample = 16;
  const byteRate = sampleRate * numChannels * (bitsPerSample / 8);
  const blockAlign = numChannels * (bitsPerSample / 8);
  const dataSize = pcmData.length * (bitsPerSample / 8);
  const fileSize = 36 + dataSize;

  const buffer = new ArrayBuffer(fileSize + 8);
  const view = new DataView(buffer);

  // Cabecera RIFF
  view.setUint32(0, 0x52494646, false); // "RIFF"
  view.setUint32(4, fileSize, true);
  view.setUint32(8, 0x57415645, false); // "WAVE"

  // Sub-chunk "fmt "
  view.setUint32(12, 0x666d7420, false); // "fmt "
  view.setUint32(16, 16, true); // Sub-chunk size
  view.setUint16(20, 1, true); // Audio format (1 for PCM)
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitsPerSample, true);

  // Sub-chunk "data"
  view.setUint32(36, 0x64617461, false); // "data"
  view.setUint32(40, dataSize, true);

  // Datos de audio
  const pcm16 = new Int16Array(buffer, 44);
  pcm16.set(pcmData);

  return new Blob([view], { type: 'audio/wav' });
}


/**
 * --- NUEVA FUNCIÓN CENTRALIZADA ---
 * Genera un Blob de audio a partir de un texto usando la API de Google TTS.
 * @param {string} text - El texto a convertir en voz.
 * @param {string} apiKey - Tu clave de API de Google.
 * @returns {Promise<Blob|null>} - Una promesa que resuelve a un Blob de audio WAV o null si falla.
 */
export async function generateAudio(text, apiKey) {
  if (!text) return null;

  const payload = {
    contents: [{ parts: [{ text }] }],
    generationConfig: {
      responseModalities: ["AUDIO"],
      speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: "Kore" } } }
    },
    model: "gemini-2.5-flash-preview-tts"
  };
  
  const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent?key=${apiKey}`;

  const response = await fetch(apiUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    const errorBody = await response.json();
    console.error('Error de la API de TTS:', errorBody);
    throw new Error('La llamada a la API de TTS falló.');
  }

  const result = await response.json();
  const part = result?.candidates?.[0]?.content?.parts?.[0];
  const audioData = part?.inlineData?.data;
  const mimeType = part?.inlineData?.mimeType;

  if (audioData && mimeType && mimeType.startsWith("audio/")) {
    const sampleRateMatch = mimeType.match(/rate=(\d+)/);
    const sampleRate = sampleRateMatch ? parseInt(sampleRateMatch[1], 10) : 24000;
    const pcmData = base64ToArrayBuffer(audioData);
    const pcm16 = new Int16Array(pcmData);
    return pcmToWav(pcm16, 1, sampleRate); // 1 canal (mono)
  }

  return null;
}

