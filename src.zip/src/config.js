// Por favor, pega tu clave de API de Google AI Studio aquí.
// Esta clave se usará para generar la voz de alta calidad.
// Asegúrate de que la API "Generative Language API" está activada en tu proyecto de Google Cloud.
export const GEMINI_API_KEY = "AIzaSyAatwbnXTuqLKUvDPa_M6mhGym8FG0SmPM";
